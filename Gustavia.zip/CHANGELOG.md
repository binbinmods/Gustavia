# 0.1.1

<!-- TODO: Fixed a bug with cards losing their stanza requirements -->

Added Vitalizing Serenade Items - Let me know if they are too busted and should be removed.

Added some of the Balance Patch cards - again let me know if they are over tuned.

# 0.1.0

Initial concept
