# 0.1.4

Fixed bug with certain cards cast by enemies.

# 0.1.3

Added Kaby skin

# 0.1.2

Fixed a bug with Ceaseless Serenade adding multiple copies. This might break a couple other cards (unsure, it shouldn't but it might). Apologies if it does. Just let me know

# 0.1.1

<!-- TODO: Fixed a bug with cards losing their stanza requirements -->

Added Vitalizing Serenade Items - Let me know if they are too busted and should be removed.

Added some of the Balance Patch cards - again let me know if they are over tuned.

# 0.1.0

Initial concept
